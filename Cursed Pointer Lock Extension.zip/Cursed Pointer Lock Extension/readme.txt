A little wonky to start it - hit the down arrow, then escape key to activate.
Probably some JS wizardry to fix that but I am no wizard.
To stop, hit the down arror again.